from easypy import EPError

a = str(input('Error: '))
lol = EPError(a, 1)
raise lol
