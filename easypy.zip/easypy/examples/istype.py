from easypy import *

def Test():
	a = ipn('Type in something: \n')
	prn(issth(a))

Test()