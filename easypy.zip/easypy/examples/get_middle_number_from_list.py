from easypy import midnum

a = (1, 2, 3, 4, 5, 6, 7, 8)
a = list(a)
b = midnum(a, True) # a = list, True = also return middleIndex
print(b)