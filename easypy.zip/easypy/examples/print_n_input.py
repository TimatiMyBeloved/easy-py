from easypy import *

def Test():
	prn('Hello!')
	a = ipn('What is your name? ')
	prn(f'My name is {a}')