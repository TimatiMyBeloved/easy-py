p = {0: '[EP-M]', 1: '[EP-Err]'}
e = {0: 'WrongParamType', 1: 'Called from examples'}

print(f"{p[0]} Using EasyPy-0.0.1")
print(f"{p[0]} Full documentation on GitHub:")
print(f"{p[0]} https://github.com/TimatiMyBeloved/easy-py")

# Error handler
class EPError(Exception):
	def __init__(self, *args):
		if args:
			self.message = args[0]
			self.errorcode = args[1]
		else:
			self.message = None
			self.errorcode = None

	def __str__(self):
		print(f'{p[1]} Calling error')
		if self.message and self.errorcode:
			self.error = e[self.errorcode]
			return '{0}: {1} ({2})'.format(p[1], self.message, self.error)
		else:
			if self.errorcode:
				self.error = e[self.errorcode]
				return '{0}: ?? ({1})'.format(p[1], self.error)
			elif self.message:
				return '{0}: {1} ({2})'.format(p[1], self.message, e[0])
			else:
				return '{0}: ?? ({1})'.format(p[1], e[0]) 

# prn and ipn
# It's just a shorter version  of print and input
def prn(txt):
	print(txt)

def ipn(txt):
	ok = input(txt)
	return ok

# Shorter versions of
# if type(arg) == <type>: ... 
def isint(arg): # Checks if arg is integer
	if type(arg) == int:
		return True
	else:
		return False

def isfloat(arg): # Checks if arg is float
	if type(arg) == float:
		return True
	else:
		return False

def isstr(arg): # Checks if arg is string
	if type(arg) == str:
		return True
	else:
		return False

def is_tdls(arg): # Checks if arg is tuple / dictionary / list / set
	if type(arg) == tuple:
		return 1
	elif type(arg) == dict:
		return 2
	elif type(arg) == list:
		return 3
	elif type(arg) == set:
		return 4
	else:
		return 0

def issth(arg):  # Checks if arg is tuple / dictionary / list / set / string / float / int
	d = ''
	if isint(arg):
		d = f'type {arg} = int'
	if isfloat(arg):
		d = f'type {arg} = float'
	if isstr(arg):
		d = f'type {arg} = str'
	if is_tdls(arg) != 0:
		if is_tdls(arg) == 1:
			d = f'type {arg} = tuple'
		if is_tdls(arg) == 2:
			d = f'type {arg} = dict'
		if is_tdls(arg) == 3:
			d = f'type {arg} = list'
		if is_tdls(arg) == 4:
			d = f'type {arg} = set'
	return d

# Math
def even_or_odd(num):
	if type(num) != int:
		try:
			num = int(num)
		except Exception:
			raise EPError(f"Ccould not convert type(num) into int", 0)
	elif type(num) == int:
		if num % 2 == 0:
			return True
		else:
			return False

def midnum(arg,a):
	if type(arg) == str or type(arg) == int or type(arg) == float or type(arg) == slice:
		print('Converting arg into list')
		arg = list(arg)
	else:
		argl = len(arg)
		middle = (argl-1)/2
		if a:
			return arg[int(middle)], middle
		else:
			return arg[int(middle)]